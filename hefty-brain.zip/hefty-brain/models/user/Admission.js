import mongoose from "mongoose";

const AdmissionSchema = mongoose.Schema({
  name: {
    type: String,
    required: [true, "Please provide Name"],
  },

  email: {
    type: String,
    required: [true, "Please provide email"],
    unique: true,
  },

  phoneNumber: {
    type: Number,
    required: [true, "Please provide Phone Number"],
    unique: true,
  },

  graduate: {
    type: String,
    required: [true, "Provide Graduate Name"],
  },

  degree: {
    type: String,
    required: [true, "Provide Degree Name"],
  },

  program: {
    type: String,
    required: [true, "Provide Program Name"],
  },

  year: {
    type: String,
    required: [true, "Provide Year Name"],
  },

  section: {
    type: String,
    required: [true, "Provide Section Name"],
  },

  batch: {
    type: String,
    required: [true, "Provide Batch"],
  },

  alumni: {
    type: Boolean,
    default: false,
  },

  tuitionFee: {
    type: Number,
    required: [true, "Provide Tuition Fee"],
  },

  hostelFee: {
    type: Number,
    default: 0,
  },

  busFee: {
    type: Number,
    default: 0,
  },

  paidFee: {},

  attendenceDeatils: {},
});

export default mongoose.model("Admission", AdmissionSchema);

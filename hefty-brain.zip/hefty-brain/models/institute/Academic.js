import mongoose from "mongoose";

const AcademicSchema = mongoose.Schema(
  {
    academicYear: {
      type: String,
      required: [true, "Please provide Academic Year"],
      unique: true,
    },
    oddSemStartDate: {
      type: Number,
      required: [true, "Please Provide Odd Semester Start Date"],
    },
    oddSemEndDate: {
      type: Number,
      required: [true, "Please Provide Odd Semester End Date"],
    },
    evenSemStartDate: {
      type: Number,
      required: [true, "Please Provide Even Semester Start Date"],
    },
    evenSemEndDate: {
      type: Number,
      required: [true, "Please Provide Even Semester End Date"],
    },
  },
  { timestamps: true }
);

export default mongoose.model("Academic", AcademicSchema);

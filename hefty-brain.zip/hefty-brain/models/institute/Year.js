import mongoose from "mongoose";

const YearSchema = mongoose.Schema(
  {
    yearName: {
      type: String,
      required: [true, "Provide Year Name"],
      unique: true,
    },
  },
  { timestamps: true }
);

export default mongoose.model("Year", YearSchema);

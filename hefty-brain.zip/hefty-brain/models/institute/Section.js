import mongoose from "mongoose";

const SectionSchema = mongoose.Schema(
  {
    sectionName: {
      type: String,
      required: [true, "Provide Section Name"],
      unique: true,
    },
  },
  { timestamps: true }
);

export default mongoose.model("Sections", SectionSchema);

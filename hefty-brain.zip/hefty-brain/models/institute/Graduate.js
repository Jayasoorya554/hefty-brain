import mongoose from "mongoose";

const GraduateSchema = mongoose.Schema(
  {
    graduateName: {
      type: String,
      required: [true, "Please Provide Graduate Name"],
      unique: true,
    },
  },
  { timestamps: true }
);

export default mongoose.model("Graduate", GraduateSchema);

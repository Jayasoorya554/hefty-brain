import mongoose from "mongoose";

const ClassSchema = mongoose.Schema(
  {
    graduate: {
      type: String,
      required: [true, "Provide Graduate Name"],
    },
    degree: {
      type: String,
      required: [true, "Provide Degree Name"],
    },
    program: {
      type: String,
      required: [true, "Provide Program Name"],
    },
    year: {
      type: String,
      required: [true, "Provide Year Name"],
    },
    section: {
      type: String,
      required: [true, "Provide Section Name"],
    },
  },
  { timestamps: true }
);

export default mongoose.model("Class", ClassSchema);

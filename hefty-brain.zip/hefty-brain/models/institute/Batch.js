import mongoose from "mongoose";

const BatchSchema = mongoose.Schema(
  {
    batch: {
      type: String,
      required: [true, "Provide Bacth Name"],
      unique: true,
    },
  },
  { timestamps: true }
);

export default mongoose.model("Batch", BatchSchema);

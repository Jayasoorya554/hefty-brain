import mongoose from "mongoose";

const DegreeSchema = mongoose.Schema(
  {
    degreeName: {
      type: String,
      required: [true, "Provide Degree Name"],
      unique: true,
    },
    graduateId: {
      type: mongoose.Types.ObjectId,
      required: [true, "Provide Graduate"],
    },
  },
  { timestamps: true }
);

export default mongoose.model("Degrees", DegreeSchema);

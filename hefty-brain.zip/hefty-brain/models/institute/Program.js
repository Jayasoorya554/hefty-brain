import mongoose from "mongoose";

const ProgramSchema = mongoose.Schema(
  {
    programName: {
      type: String,
      required: [true, "Provide Program Name"],
      unique: true,
    },
    programShortName: {
      type: String,
      required: [true, "provide Program Short Name"],
      unique: true,
    },
    degreeId: {
      type: mongoose.Types.ObjectId,
      required: [true, "Provide Degree Name"],
    },
  },
  { timestamps: true }
);
export default mongoose.model("Programs", ProgramSchema);

import React, { useReducer, useContext } from "react";
import axios from "axios";

import reducer from "./reducers";
import {
  DISPLAY_ALERT,
  CLEAR_ALERT,
  SETUP_INST_SUCCESS,
  SETUP_INST_BEGIN,
  SETUP_INST_ERROR,
  TOGGLE_SIDEBAR,
  LOG_OUT,
  UPDATE_INST_BEGIN,
  UPDATE_INST_ERROR,
  UPDATE_INST_SUCCESS,
} from "./actions";

const token = localStorage.getItem("token");
const institute = localStorage.getItem("institute");

const initialState = {
  toggleMenu: false,
  isLoading: false,
  showAlert: false,
  alertText: "",
  alertType: "",
  institute: institute ? JSON.parse(institute) : null,
  token: token,
};

const AppContext = React.createContext();

const AppProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const authFetch = axios.create({
    baseURL: "/api/v1",
    // headers: { Authorization: `Bearer ${state.token}` },
  });

  authFetch.interceptors.request.use(
    (config) => {
      config.headers.common["Authorization"] = `Bearer ${state.token}`;
      return config;
    },
    (e) => {
      return Promise.reject(e);
    }
  );

  authFetch.interceptors.response.use(
    (response) => {
      return response;
    },
    (error) => {
      // console.log(error.response);
      if (error.response.status === 401) {
        logOut();
      }
      return Promise.reject(error);
    }
  );

  const displayAlert = ({ alertText, alertType }) => {
    dispatch({ type: DISPLAY_ALERT, alertText, alertType });
    clearAlert();
  };

  const clearAlert = () => {
    setTimeout(() => {
      dispatch({ type: CLEAR_ALERT });
    }, 3000);
  };

  const addToStorage = ({ institute, token }) => {
    localStorage.setItem("institute", JSON.stringify(institute));
    localStorage.setItem("token", token);
  };

  const removeFromStorage = () => {
    localStorage.removeItem("institute");
    localStorage.removeItem("token");
  };

  const toggleSidebar = () => {
    dispatch({ type: TOGGLE_SIDEBAR });
  };

  const setupInst = async ({ currentInst, endPoint, alertText }) => {
    dispatch({ type: SETUP_INST_BEGIN });
    try {
      const response = await axios.post(
        `/api/v1/auth/${endPoint}`,
        currentInst
      );
      const { institute, token } = response.data;
      dispatch({ type: SETUP_INST_SUCCESS, institute, token, alertText });
      addToStorage({ institute, token });
    } catch (e) {
      dispatch({ type: SETUP_INST_ERROR, msg: e.response.data.msg });
    }
    clearAlert();
  };

  const updateUser = async (currentUser) => {
    dispatch({ type: UPDATE_INST_BEGIN });
    try {
      const { data } = await authFetch.patch("/auth/updateUser", currentUser);
      const { institute, token } = data;

      dispatch({ type: UPDATE_INST_SUCCESS, institute, token });
      addToStorage({ institute, token });
    } catch (e) {
      if (e.response.status !== 401) {
        dispatch({ type: UPDATE_INST_ERROR, msg: e.response.data.msg });
      }
    }
    clearAlert();
  };

  const logOut = () => {
    dispatch({ type: LOG_OUT });
    removeFromStorage();
  };

  return (
    <AppContext.Provider
      value={{
        ...state,
        displayAlert,
        setupInst,
        toggleSidebar,
        logOut,
        updateUser,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

const useAppContext = () => {
  return useContext(AppContext);
};

export { AppProvider, initialState, useAppContext };

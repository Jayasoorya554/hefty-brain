import {
  CLEAR_ALERT,
  DISPLAY_ALERT,
  SETUP_INST_SUCCESS,
  SETUP_INST_BEGIN,
  SETUP_INST_ERROR,
  TOGGLE_SIDEBAR,
  LOG_OUT,
  UPDATE_INST_BEGIN,
  UPDATE_INST_ERROR,
  UPDATE_INST_SUCCESS,
} from "./actions";
import { initialState } from "./appContext";

const reducer = (state, action) => {
  switch (action.type) {
    case DISPLAY_ALERT:
      return {
        ...state,
        showAlert: true,
        alertType: action.alertType,
        alertText: action.alertText,
      };
    case CLEAR_ALERT:
      return {
        ...state,
        showAlert: false,
        alertType: "",
        alertText: "",
      };
    case SETUP_INST_BEGIN:
      return {
        ...state,
        isLoading: true,
      };
    case SETUP_INST_SUCCESS:
      return {
        ...state,
        institute: action.institute,
        token: action.token,
        isLoading: false,
        showAlert: true,
        alertType: "success",
        alertText: action.alertText,
      };
    case SETUP_INST_ERROR:
      return {
        ...state,
        isLoading: false,
        showAlert: true,
        alertType: "danger",
        alertText: action.msg,
      };
    case UPDATE_INST_BEGIN:
      return {
        ...state,
        isLoading: true,
      };
    case UPDATE_INST_SUCCESS:
      return {
        ...state,
        institute: action.institute,
        token: action.token,
        isLoading: false,
        showAlert: true,
        alertType: "success",
        alertText: "Update Success",
      };
    case UPDATE_INST_ERROR:
      return {
        ...state,
        isLoading: false,
        showAlert: true,
        alertType: "danger",
        alertText: action.msg,
      };
    case TOGGLE_SIDEBAR:
      return {
        ...state,
        toggleMenu: !state.toggleMenu,
      };
    case LOG_OUT:
      return {
        ...initialState,
        institute: null,
        token: null,
      };
    default:
      throw new Error(`No such action: ${action.type}`);
  }
};

export default reducer;

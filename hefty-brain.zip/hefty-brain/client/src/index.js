import React from "react";
// import ReactDOM from "react-dom";
import { createRoot } from "react-dom/client";
import "normalize.css";
import "./styles.scss";
import App from "./App";
import { AppProvider } from "./context/appContext";

// ReactDOM.render(
//   <React.StrictMode>
//     <AppProvider>
//       <App />
//     </AppProvider>
//   </React.StrictMode>,
//   document.getElementById("root")
// );

const root = createRoot(document.getElementById("root"));
const Main = (
  <React.StrictMode>
    <AppProvider>
      <App />
    </AppProvider>
  </React.StrictMode>
);
root.render(Main);

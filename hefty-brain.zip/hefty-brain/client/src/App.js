import { BrowserRouter, Routes, Route } from "react-router-dom";
import {
  Landing,
  NotFound,
  Register,
  Dashboard,
  SharedLayout,
  Institute,
  ProtectedRoute,
} from "./pages";
import { Profile } from "./components";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path="/"
          element={
            <ProtectedRoute>
              <SharedLayout />
            </ProtectedRoute>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="institute" element={<Institute />}>
            <Route path="profile" element={<Profile />} />
          </Route>
        </Route>
        <Route path="register" element={<Register />} />
        <Route path="landing" element={<Landing />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

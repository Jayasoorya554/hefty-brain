import moment from "moment";
import { useState } from "react";
import { useAppContext } from "../../context/appContext";
import Alert from "../Alert";
import { FormRow } from "../index";

const academicState = {
  startDate: moment(),
  endDate: moment(),
};

const AcademicYear = () => {
  const [values, setValues] = useState(academicState);

  const { showAlert, displayAlert } = useAppContext();

  const handleChange = (e) => {
    setValues({ ...values, [e.target.name]: moment(e.target.value) });
  };

  const onSubmit = () => {
    const isBefore = values.startDate.isBefore(values.endDate);
    if (!isBefore) {
      displayAlert({ alertType: "danger", alertText: "Set proper date" });
      return;
    } else {
      displayAlert({
        alertText: "Academic Year Created Successfully!",
        alertType: "success",
      });
    }
  };

  return (
    <div className="academic">
      {!showAlert && <h1>Academic Year details</h1>}
      {showAlert && <Alert />}
      <div className="academiccontent">
        <div className="academicentry">
          <FormRow
            type="date"
            labelText="Start Date"
            value={values.startDate.format("YYYY-MM-DD")}
            name="startDate"
            handleChange={handleChange}
          />
          <FormRow
            type="date"
            labelText="End Date"
            value={values.endDate.format("YYYY-MM-DD")}
            name="endDate"
            handleChange={handleChange}
          />
          <button className="addacademic" onClick={onSubmit}>
            Add Academic
          </button>
        </div>
        <div className="academictable">
          <table>
            <thead>
              <tr>
                <th>S.No</th>
                <th>Start Date</th>
                <th>End Date</th>
              </tr>
            </thead>
          </table>
          <p>No data to show here</p>
        </div>
      </div>
    </div>
  );
};

export default AcademicYear;

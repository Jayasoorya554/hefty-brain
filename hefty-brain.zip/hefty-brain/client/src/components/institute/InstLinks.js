import { NavLink } from "react-router-dom";

const InstLinks = () => {
  return (
    <div className="subnav">
      <nav>
        <NavLink to="profile" className="sublink">
          Profile
        </NavLink>
      </nav>
    </div>
  );
};

export default InstLinks;

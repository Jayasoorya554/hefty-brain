import { useState } from "react";
import { useAppContext } from "../../context/appContext";
import { Alert } from "../../components";
import FormRow from "../FormRow";

const Profile = () => {
  const { institute, showAlert, displayAlert, updateUser, isLoading } =
    useAppContext();
  const [name, setName] = useState(institute?.name);
  const [email, setEmail] = useState(institute?.email);
  const [contactNumber, setContactNubmer] = useState(institute?.contactNumber);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name || !email || !contactNumber) {
      displayAlert({
        alertType: "danger",
        alertText: "Please provide all values",
      });
      return;
    }

    updateUser({ name, email, contactNumber });
  };

  return (
    <div>
      <h3>Profile</h3>
      {showAlert && <Alert />}
      <form onSubmit={handleSubmit}>
        <FormRow
          type="text"
          name={name}
          value={name}
          handleChange={(e) => setName(e.target.value)}
        />
        <FormRow
          type="email"
          name={email}
          value={email}
          handleChange={(e) => setEmail(e.target.value)}
        />
        <FormRow
          type="text"
          name={contactNumber}
          value={contactNumber}
          handleChange={(e) => setContactNubmer(e.target.value)}
        />
        <button disabled={isLoading}>Submit</button>
      </form>
    </div>
  );
};

export default Profile;

import { NavLink } from "react-router-dom";
import { useAppContext } from "../context/appContext";
import { MdSpaceDashboard } from "react-icons/md";
import { BsBuilding } from "react-icons/bs";

const Sidebar = () => {
  const { toggleMenu } = useAppContext();
  return (
    <div className="sidebar sidebartoggle">
      <nav className="links">
        <NavLink to="/" className="link">
          <MdSpaceDashboard className="side-btn" />
          Dashboard
        </NavLink>

        <NavLink to="institute" className="link">
          <BsBuilding className="side-btn" />
          Institute
        </NavLink>
      </nav>
    </div>
  );
};

export default Sidebar;

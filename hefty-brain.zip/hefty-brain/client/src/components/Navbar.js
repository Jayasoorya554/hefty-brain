import { useAppContext } from "../context/appContext";
import { FaBars, FaPowerOff } from "react-icons/fa";

const Navbar = () => {
  const { toggleSidebar, logOut, institute } = useAppContext();

  return (
    <div className="navbar">
      <FaBars className="nav--btn" onClick={toggleSidebar} />
      <h3 className="nav--title">{institute.name}</h3>
      <FaPowerOff className="nav--btn" onClick={logOut} />
    </div>
  );
};

export default Navbar;

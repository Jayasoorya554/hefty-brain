import FormRow from "./FormRow";
import Alert from "./Alert";
import SelectOption from "./SelectOption";
import Sidebar from "./Sidebar";
import Navbar from "./Navbar";
import AcademicYear from "./institute/AcademicYear";
import Profile from "./institute/Profile";
import InstLinks from "./institute/InstLinks";
export {
  InstLinks,
  FormRow,
  Alert,
  SelectOption,
  Sidebar,
  Navbar,
  AcademicYear,
  Profile,
};

const SelectOption = ({ options, labelText, handleChange, name }) => {
  const option = options.map((val, index) => (
    <option key={index} value={val}>
      {val}
    </option>
  ));
  return (
    <div className="form">
      <label htmlFor={name} className="form--label">
        {labelText}
      </label>
      <select onChange={handleChange} name={name} className="form--select">
        {option}
      </select>
    </div>
  );
};

export default SelectOption;

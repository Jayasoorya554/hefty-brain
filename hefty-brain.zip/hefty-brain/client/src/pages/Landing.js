import { Link } from "react-router-dom";

const Landing = () => (
  <main>
    <div>
      <h1>Hefty Brain</h1>
      <p>Online solution for Institutions</p>
      <Link to="/register">Login/Register</Link>
    </div>
  </main>
);

export default Landing;

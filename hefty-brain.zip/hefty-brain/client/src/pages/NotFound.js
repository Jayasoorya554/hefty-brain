import { Link } from "react-router-dom";

import notFound from "../assets/images/notFound.svg";

const NotFound = () => {
  return (
    <div>
      <img src={notFound} alt="Not Found" />
      <h3>Page Not Found</h3>
      <p>we can't seem to find the page you're looking for</p>
      <Link to="/">back to home</Link>
    </div>
  );
};

export default NotFound;

import { Outlet } from "react-router-dom";
import { Sidebar, Navbar } from "../components";
import { useAppContext } from "../context/appContext";

const SharedLayout = () => {
  const { toggleMenu } = useAppContext();
  return (
    <div className="container">
      {!toggleMenu && <Sidebar />}
      <div className="content">
        <Navbar />
        <Outlet />
      </div>
    </div>
  );
};

export default SharedLayout;

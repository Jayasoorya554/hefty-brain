import Landing from "./Landing";
import NotFound from "./NotFound";
import Register from "./Register";
import Dashboard from "./Dashboard";
import Institute from "./Institute";
import SharedLayout from "./SharedLayout";
import ProtectedRoute from "./ProtectedRoute";

export {
  Landing,
  NotFound,
  Dashboard,
  Register,
  Institute,
  SharedLayout,
  ProtectedRoute,
};

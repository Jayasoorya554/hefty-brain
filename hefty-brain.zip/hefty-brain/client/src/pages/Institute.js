import { Outlet } from "react-router-dom";
import { InstLinks } from "../components";

const Institute = () => {
  return (
    <div>
      <InstLinks />
      <Outlet />
    </div>
  );
};

export default Institute;

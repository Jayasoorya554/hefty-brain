import { useState, useEffect } from "react";
import moment from "moment";
import { useNavigate } from "react-router-dom";

import { FormRow, Alert, SelectOption } from "../components";
import { useAppContext } from "../context/appContext";

const initialState = {
  name: "",
  code: "",
  email: "",
  address: "",
  city: "",
  district: "",
  state: "",
  postalCode: "",
  contactNumber: "",
  contactPerson: "",
  type: "Co-Ed",
  password: "",
  confirmPassword: "",
  createdAt: moment().valueOf(),
  userType: "admin",
  isMember: true,
};
const Register = () => {
  const navigate = useNavigate();
  const [values, setValues] = useState(initialState);

  const { institute, isLoading, showAlert, displayAlert, setupInst } =
    useAppContext();

  const toggleMember = () => {
    setValues({ ...values, isMember: !values.isMember });
  };

  const handleChange = (e) => {
    setValues({ ...values, [e.target.name]: e.target.value });
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const {
      name,
      code,
      email,
      address,
      city,
      district,
      state,
      postalCode,
      contactNumber,
      contactPerson,
      type,
      password,
      createdAt,
      userType,
      confirmPassword,
      isMember,
    } = values;
    if (
      !email ||
      !password ||
      (!isMember && !name) ||
      (!isMember && !code) ||
      (!isMember && !address) ||
      (!isMember && !city) ||
      (!isMember && !district) ||
      (!isMember && !state) ||
      (!isMember && !postalCode) ||
      (!isMember && !contactNumber) ||
      (!isMember && !contactPerson)
    ) {
      displayAlert({
        alertText: "Please provide all values!",
        alertType: "danger",
      });
      return;
    }
    if (!isMember && password != confirmPassword) {
      displayAlert({ alertType: "danger", alertText: "Password not matched" });
      return;
    }
    const currentInst = {
      name,
      code,
      email,
      address,
      city,
      district,
      state,
      postalCode,
      contactNumber,
      contactPerson,
      type,
      password,
      createdAt,
      userType,
    };
    if (isMember) {
      setupInst({
        currentInst,
        endPoint: "login",
        alertText: "Login successful. Redirecting..!",
      });
    } else {
      setupInst({
        currentInst,
        endPoint: "login",
        alertText: "Register successful. Redirecting..!",
      });
    }
  };

  useEffect(() => {
    if (institute) {
      setTimeout(() => {
        navigate("/");
      }, 3000);
    }
  }, [institute, navigate]);

  return (
    <div className="full--page">
      <div className="register">
        <h1 className="register--title">Hefty Brain</h1>
        <h3 className="register--subtitle">
          {values.isMember ? "Login" : "Register"}
        </h3>
        {showAlert && <Alert />}
        <form onSubmit={onSubmit} className="register--form">
          {!values.isMember && (
            <FormRow
              type="text"
              name="name"
              value={values.name}
              handleChange={handleChange}
              labelText="Name"
            />
          )}
          <FormRow
            type="email"
            name="email"
            value={values.email}
            handleChange={handleChange}
            labelText="Email"
          />
          {!values.isMember && (
            <FormRow
              type="text"
              name="code"
              value={values.code}
              handleChange={handleChange}
              labelText="Code"
            />
          )}
          {!values.isMember && (
            <FormRow
              type="text"
              name="address"
              value={values.address}
              handleChange={handleChange}
              labelText="Address"
            />
          )}
          {!values.isMember && (
            <FormRow
              type="text"
              name="city"
              value={values.city}
              handleChange={handleChange}
              labelText="City"
            />
          )}
          {!values.isMember && (
            <FormRow
              type="text"
              name="district"
              value={values.district}
              handleChange={handleChange}
              labelText="District"
            />
          )}
          {!values.isMember && (
            <FormRow
              type="text"
              name="state"
              value={values.state}
              handleChange={handleChange}
              labelText="State"
            />
          )}
          {!values.isMember && (
            <FormRow
              type="text"
              name="postalCode"
              value={values.postalCode}
              handleChange={handleChange}
              labelText="Postal Code"
            />
          )}
          {!values.isMember && (
            <FormRow
              type="text"
              name="contactNumber"
              value={values.contactNumber}
              handleChange={handleChange}
              labelText="Contact Number"
            />
          )}
          {!values.isMember && (
            <FormRow
              type="text"
              name="contactPerson"
              value={values.contactPerson}
              handleChange={handleChange}
              labelText="Contact Person"
            />
          )}
          {!values.isMember && (
            <SelectOption
              name="type"
              options={["Co-Ed", "Womens"]}
              labelText="Type"
              handleChange={handleChange}
              value={values.type}
            />
          )}
          <FormRow
            type="password"
            name="password"
            value={values.password}
            handleChange={handleChange}
            labelText="Password"
          />
          {!values.isMember && (
            <FormRow
              type="password"
              name="confirmPassword"
              value={values.confirmPassword}
              handleChange={handleChange}
              labelText="Confirm Password"
            />
          )}
          <button className="btn--primary" type="submit" disabled={isLoading}>
            Submit
          </button>
          <p className="register--content">
            {values.isMember ? "Not a member yet? " : "Already a member? "}
            <button
              className="btn--secondary "
              type="button"
              onClick={toggleMember}
            >
              {values.isMember ? "Register" : "Login"}
            </button>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Register;

import express from "express";
import {
  addGraduate,
  getGraduate,
} from "../../controllers/institute/Graduate.js";

const router = express.Router();

router.route("/add-graduate").post(addGraduate);
router.route("/get-all-graduate").get(getGraduate);

export default router;

import express from "express";
import { addSection, getSection } from "../../controllers/institute/Section.js";

const router = express.Router();

router.route("/add-section").post(addSection);
router.route("/get-section").get(getSection);

export default router;

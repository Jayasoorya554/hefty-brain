import express from "express";
import { addYear, getYear } from "../../controllers/institute/Year.js";

const router = express.Router();

router.route("/add-year").post(addYear);
router.route("/get-year").get(getYear);

export default router;

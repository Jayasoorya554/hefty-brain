import express from "express";
import { addBatch, getBatch } from "../../controllers/institute/Batch.js";

const router = express.Router();

router.route("/add-batch").post(addBatch);
router.route("/get-batch").get(getBatch);

export default router;

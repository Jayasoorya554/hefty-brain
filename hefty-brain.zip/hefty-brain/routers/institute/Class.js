import express from "express";
import { addClass, getClass } from "../../controllers/institute/Class.js";

const router = express.Router();

router.route("/add-class").post(addClass);
router.route("/get-class").get(getClass);

export default router;

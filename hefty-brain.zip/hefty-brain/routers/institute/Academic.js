import express from "express";
import {
  addAcademic,
  getAllAcademic,
} from "../../controllers/institute/Academic.js";

const router = express.Router();

router.route("/add-academic").post(addAcademic);
router.route("/get-all-academic").get(getAllAcademic);

export default router;

import express from "express";
import { addDegree, getDegree } from "../../controllers/institute/Degree.js";

const router = express.Router();

router.route("/add-degree").post(addDegree);
router.route("/get-all-degree").get(getDegree);

export default router;

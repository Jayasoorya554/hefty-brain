import express from "express";
import { addProgram, allProgram } from "../../controllers/institute/Program.js";

const router = express.Router();

router.route("/add-program").post(addProgram);
router.route("/get-program").get(allProgram);

export default router;

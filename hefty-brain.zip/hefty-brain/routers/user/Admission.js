import express from "express";
import {
  addStudent,
  getAdmission,
  splitAdmission,
} from "../../controllers/user/Admission.js";

const router = express.Router();

router.route("/add-student").post(addStudent);
router.route("/get-admission").get(getAdmission);
router.route("/split-admission").post(splitAdmission);

export default router;

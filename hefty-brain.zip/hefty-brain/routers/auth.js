import express from "express";
import { register, login, updateInst } from "../controllers/auth.js";
import { authUser } from "../middlewares/index.js";

const router = express.Router();

router.route("/register").post(register);
router.route("/login").post(login);
router.route("/update").patch(authUser, updateInst);

export default router;

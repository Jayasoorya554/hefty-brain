import authRouter from "./auth.js";
import academicRouter from "./institute/Academic.js";
import degreeRouter from "./institute/Degree.js";
import graduateRouter from "./institute/Graduate.js";
import programRouter from "./institute/Program.js";
import classRouter from "./institute/Class.js";
import batchRouter from "./institute/Batch.js";
import sectionRouter from "./institute/Section.js";
import yearRouter from "./institute/Year.js";
import admissionRouter from "./user/Admission.js";

export {
  authRouter,
  academicRouter,
  degreeRouter,
  graduateRouter,
  programRouter,
  classRouter,
  batchRouter,
  sectionRouter,
  yearRouter,
  admissionRouter,
};

import { StatusCodes } from "http-status-codes";
import Admission from "../../models/user/Admission.js";
import { BadRequestError } from "../../errors/index.js";
import mongoose from "mongoose";

export const addStudent = async (req, res) => {
  const {
    name,
    email,
    phoneNumber,
    graduate,
    degree,
    program,
    year,
    section,
    batch,
    tuitionFee,
  } = req.body;

  if (
    !name ||
    !email ||
    !phoneNumber ||
    !graduate ||
    !degree ||
    !program ||
    !year ||
    !section ||
    !batch ||
    !tuitionFee
  ) {
    throw new BadRequestError("Please provide all values");
  }

  const admission = await Admission.create({
    name,
    email,
    phoneNumber,
    graduate,
    degree,
    program,
    year,
    section,
    batch,
    tuitionFee,
  });

  res.status(StatusCodes.CREATED).json({ admission });
};

export const getAdmission = async (req, res) => {
  const admissions = await Admission.find();
  res.status(StatusCodes.OK).json({ admissions });
};

export const splitAdmission = async (req, res) => {
  const { graduate, degree, program, year, section, batch } = req.body;
  let students = [];
  let groupStudents;
  if (batch && !graduate && !degree && !program && !year && !section) {
    students = await Admission.aggregate([{ $match: { batch: batch } }]);

    groupStudents = await Admission.aggregate([
      {
        $group: {
          _id: {
            batch: "$batch",
            graduate: "$graduate",
            degree: "$degree",
            program: "$program",
            section: "$section",
          },
          count: { $sum: 1 },
        },
      },
    ]);
  } else {
    if (!batch && graduate && degree && program && year && section) {
      students = await Admission.aggregate([
        {
          $match: {
            graduate: graduate,
            degree: degree,
            program: program,
            year: year,
            section: section,
          },
        },
      ]);

      groupStudents = await Admission.aggregate([
        {
          $group: {
            _id: { degree: "$degree", program: "$program", year: "$year" },
            count: { $sum: 1 },
          },
        },
      ]);
    } else if (!batch && graduate && degree && program && year) {
      students = await Admission.aggregate([
        {
          $match: {
            graduate: graduate,
            degree: degree,
            program: program,
            year: year,
          },
        },
      ]);
    } else if (!batch && graduate && degree && program) {
      students = await Admission.aggregate([
        {
          $match: {
            graduate: graduate,
            degree: degree,
            program: program,
          },
        },
      ]);
    } else if (!batch && graduate && degree) {
      students = await Admission.aggregate([
        {
          $match: {
            graduate: graduate,
            degree: degree,
          },
        },
      ]);
    } else if (!batch && graduate) {
      students = await Admission.aggregate([
        {
          $match: {
            graduate: graduate,
          },
        },
      ]);
    }
  }
  res
    .status(StatusCodes.OK)
    .json({ students, groupStudents, totalCount: students.length });
};

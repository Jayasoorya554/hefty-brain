import { StatusCodes } from "http-status-codes";
import { BadRequestError } from "../../errors/index.js";
import Batch from "../../models/institute/Batch.js";

export const addBatch = async (req, res) => {
  const { batch } = req.body;

  if (!batch) {
    throw new BadRequestError("Provide Batch Year");
  }

  const result = await Batch.create({
    batch,
  });

  res.status(StatusCodes.CREATED).json({ batch: result });
};

export const getBatch = async (req, res) => {
  const batches = await Batch.find();

  res.status(StatusCodes.OK).json({ batches });
};

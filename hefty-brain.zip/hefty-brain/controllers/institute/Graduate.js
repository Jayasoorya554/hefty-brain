import { StatusCodes } from "http-status-codes";
import Graduate from "../../models/institute/Graduate.js";

import { BadRequestError } from "../../errors/index.js";

export const addGraduate = async (req, res) => {
  const { graduateName } = req.body;
  if (!graduateName) {
    throw new BadRequestError("Provide Graduate name");
  }

  const graduate = await Graduate.create({ graduateName });

  res.status(StatusCodes.CREATED).json({ graduate });
};

export const getGraduate = async (req, res) => {
  const graduates = await Graduate.find();
  res.status(StatusCodes.OK).json({ graduates });
};

import { StatusCodes } from "http-status-codes";
import { BadRequestError } from "../../errors/index.js";
import Year from "../../models/institute/Year.js";

export const addYear = async (req, res) => {
  const { yearName } = req.body;

  if (!yearName) {
    throw new BadRequestError("Provide Year Name");
  }

  const year = await Year.create({ yearName });

  res.status(StatusCodes.CREATED).json({ year });
};

export const getYear = async (req, res) => {
  const sections = await Year.find();
  res.status(StatusCodes.OK).json({ sections });
};

import { StatusCodes } from "http-status-codes";
import Program from "../../models/institute/Program.js";
import { BadRequestError } from "../../errors/index.js";

export const addProgram = async (req, res) => {
  const { programName, degreeId, programShortName } = req.body;
  if ((!programName || !degreeId, !programShortName)) {
    throw new BadRequestError("Provide all values");
  }

  const program = await Program.create({
    programName,
    degreeId,
    programShortName,
  });
  res.status(StatusCodes.CREATED).json({ program });
};

export const allProgram = async (req, res) => {
  const programs = await Program.find();
  res.status(StatusCodes.OK).json({ programs });
};

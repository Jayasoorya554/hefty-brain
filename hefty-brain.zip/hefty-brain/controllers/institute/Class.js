import { StatusCodes } from "http-status-codes";
import { BadRequestError } from "../../errors/index.js";
import ClassShema from "../../models/institute/CLass.js";

export const addClass = async (req, res) => {
  const { graduate, degree, program, year, section } = req.body;

  if (!graduate || !degree || !program || !year || !section) {
    throw new BadRequestError("Please provide all values");
  }

  const result = await ClassShema.create({
    graduate,
    degree,
    program,
    year,
    section,
  });

  res.status(StatusCodes.CREATED).json({ class: result });
};

export const getClass = async (req, res) => {
  const classes = await ClassShema.find();
  res.status(StatusCodes.OK).json({ classes });
};

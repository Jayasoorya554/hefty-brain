import { StatusCodes } from "http-status-codes";
import Academic from "../../models/institute/Academic.js";

import { BadRequestError } from "../../errors/index.js";
import moment from "moment";

export const addAcademic = async (req, res) => {
  let {
    academicYear,
    oddSemStartDate,
    oddSemEndDate,
    evenSemEndDate,
    evenSemStartDate,
  } = req.body;

  if (
    !academicYear ||
    !oddSemStartDate ||
    !oddSemEndDate ||
    !evenSemStartDate ||
    !evenSemEndDate
  ) {
    throw new BadRequestError("Please provide all values");
  }

  oddSemStartDate = moment(oddSemStartDate, "DD-MM-YYYY").valueOf();
  oddSemEndDate = moment(oddSemEndDate, "DD-MM-YYYY").valueOf();
  evenSemStartDate = moment(evenSemStartDate, "DD-MM-YYYY").valueOf();
  evenSemEndDate = moment(evenSemEndDate, "DD-MM-YYYY").valueOf();

  const academic = await Academic.create({
    academicYear,
    oddSemStartDate,
    oddSemEndDate,
    evenSemEndDate,
    evenSemStartDate,
  });

  res.status(StatusCodes.CREATED).json({ academic });
};

export const getAllAcademic = async (req, res) => {
  const academics = await Academic.find();

  res.status(StatusCodes.OK).json({ academics });
};

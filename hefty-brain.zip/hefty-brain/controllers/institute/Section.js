import { StatusCodes } from "http-status-codes";
import { BadRequestError } from "../../errors/index.js";
import Section from "../../models/institute/Section.js";

export const addSection = async (req, res) => {
  const { sectionName } = req.body;

  if (!sectionName) {
    throw new BadRequestError("Provide Section Name");
  }

  const section = await Section.create({
    sectionName,
  });

  res.status(StatusCodes.CREATED).json({ section });
};

export const getSection = async (req, res) => {
  const sections = await Section.find();

  res.status(StatusCodes.OK).json({ sections });
};

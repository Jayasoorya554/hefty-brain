import { StatusCodes } from "http-status-codes";
import Degree from "../../models/institute/Degree.js";
import { BadRequestError } from "../../errors/index.js";

export const addDegree = async (req, res) => {
  const { degreeName, graduateId } = req.body;
  if (!degreeName || !graduateId) {
    throw new BadRequestError("Provide all values");
  }

  const degree = await Degree.create({
    degreeName,
    graduateId,
  });

  res.status(StatusCodes.CREATED).json({ degree });
};

export const getDegree = async (req, res) => {
  const degrees = await Degree.find();
  res.status(StatusCodes.OK).json({ degrees });
};

// export const getMerge = async (req, res) => {
//   const graduates = await Graduate.aggregate([
//     {
//       $lookup: {
//         from: "degrees",
//         localField: "_id",
//         foreignField: "graduateId",
//         as: "degrees",
//       },
//     },
//   ]);

//   res.status(StatusCodes.OK).json({ graduates });
// };

import { StatusCodes } from "http-status-codes";
import Institute from "../models/Institute.js";

import { BadRequestError, UnAuthenticatedError } from "../errors/index.js";

export const register = async (req, res) => {
  const { name, email, contactNumber, password } = req.body;
  if (!name || !email || !contactNumber || !password) {
    throw new BadRequestError("Please provide all values");
  }

  const instExist = await Institute.findOne({ email });
  if (instExist) {
    throw new BadRequestError("Email already in use");
  }
  const institute = await Institute.create({
    name,
    email,
    contactNumber,
    password,
  });
  const token = institute.createJWT();
  res.status(StatusCodes.CREATED).json({
    institute: {
      name: institute.name,
      email: institute.email,
      contactNumber: institute.contactNumber,
      id: institute._id,
    },
    token,
  });
};

export const login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    throw new BadRequestError("Please provide all values");
  }

  const institute = await Institute.findOne({ email }).select("+password");
  if (!institute) {
    throw new UnAuthenticatedError("Email not exist");
  }
  const isPasswordCorrect = await institute.comparePassword(password);
  if (!isPasswordCorrect) {
    throw new UnAuthenticatedError("Invalid Password");
  }
  const token = institute.createJWT();
  institute.password = undefined;
  res.status(StatusCodes.OK).json({
    institute,
    token,
  });
};

export const updateInst = async (req, res) => {
  const { name, email, contactNumber } = req.body;
  if (!email || !name || !contactNumber) {
    throw new BadRequestError("Please provide all values");
  }

  const institute = await Institute.findOne({ _id: req.institute.id });

  institute.name = name;
  institute.email = email;
  institute.contactNumber = contactNumber;

  await institute.save();
  const token = institute.createJWT();

  res.status(StatusCodes.OK).json({ institute, token });
};

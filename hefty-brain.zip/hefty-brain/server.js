// import cors from "cors";
import express from "express";
import dotenv from "dotenv";
import "express-async-errors";
import morgan from "morgan";

import connectDB from "./db/connect.js";
import { notFound, errorHandler, authUser } from "./middlewares/index.js";
import {
  authRouter,
  academicRouter,
  degreeRouter,
  graduateRouter,
  programRouter,
  classRouter,
  batchRouter,
  sectionRouter,
  yearRouter,
  admissionRouter,
} from "./routers/index.js";

const app = express();
dotenv.config();

// app.use(cors());
if (process.env.NODE_ENV !== "production") {
  app.use(morgan("dev"));
}
app.use(express.json());

app.get("/", (req, res) => {
  res.json({ msg: "Welcome to Node" });
});

app.get("/api/v1", (req, res) => {
  res.json({ msg: "Welcome to Node" });
});

app.use("/api/v1/auth", authRouter);
app.use("/api/v1/institute", authUser, academicRouter);
app.use("/api/v1/institute", authUser, graduateRouter);
app.use("/api/v1/institute", authUser, degreeRouter);
app.use("/api/v1/institute", authUser, programRouter);
app.use("/api/v1/institute", authUser, classRouter);
app.use("/api/v1/institute", authUser, batchRouter);
app.use("/api/v1/institute", authUser, sectionRouter);
app.use("/api/v1/institute", authUser, yearRouter);
app.use("/api/v1/user", authUser, admissionRouter);

app.use(notFound);
app.use(errorHandler);

const port = process.env.PORT || 5000;

const start = async () => {
  try {
    await connectDB(process.env.MONGODB_URL);
    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
  } catch (e) {
    console.log(e);
  }
};

start();
